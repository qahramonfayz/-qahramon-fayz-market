# Qahramon Fayz Market 24/7 — MVP v2

Qo‘shilganlar:
- mahsulot ombor soni
- savatcha va jami hisob
- to‘lov usuli oynasi
- buyurtma yaratish va Buyurtmalarim
- buyurtma holati
- admin panel demo
- admin orqali demo mahsulot qo‘shish
- mijoz/admin rejimlari

Ishga tushirish:
npm install
npx expo start

Eslatma: real to‘lov, real yetkazib berish, SMS/OTP va internetdagi umumiy baza uchun backend hamda tegishli xizmat hisoblari kerak bo‘ladi.
